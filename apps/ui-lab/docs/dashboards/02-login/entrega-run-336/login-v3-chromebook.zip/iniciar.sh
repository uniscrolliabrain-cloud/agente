#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/site"
echo "Abre http://localhost:8080/?embed=1&view=login-v3"
python3 -m http.server 8080 --bind 127.0.0.1
