import{c as t}from"./index-BhZdjHc9.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=t("Folder",[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",key:"1kt360"}]]),e="https://agntiapro.com",i={notice:"aviso-legal.html",privacy:"privacidad.html",terms:"terminos.html",cookies:"cookies.html",ai:"transparencia-ia.html",trust:"confianza.html"};function o(a){return e}function c(a){return new URL(i[a],o()).href}export{r as F,c as a,i as l};
